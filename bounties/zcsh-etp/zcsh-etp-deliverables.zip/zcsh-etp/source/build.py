"""Build editable and outlined SVGs, plus PNG exports. Run from any directory.
Dependencies: fonttools, uharfbuzz, cairosvg (see requirements.txt).
"""
from pathlib import Path
from xml.sax.saxutils import escape
import base64, io, json
import xml.etree.ElementTree as ET
from fontTools.ttLib import TTFont
from fontTools.varLib.instancer import instantiateVariableFont
from fontTools.pens.svgPathPen import SVGPathPen
import uharfbuzz as hb
import cairosvg

ROOT = Path(__file__).resolve().parents[1]
A, O = ROOT/'assets', ROOT/'exports'
O.mkdir(exist_ok=True)
W,H=1600,1760
INK='#152D40'; BLUE='#1D71B8'; MUTED='#506776'; LINE='#A3B7C6'; PAPER='#FAFCFE'; YELLOW='#F4B728'
fonts={}
for family, filename, weights in [('DM Sans','DM-Sans.ttf',[400,500,600,700]),('Syne','Syne.ttf',[600,700])]:
    for weight in weights:
        variable=TTFont(A/filename)
        axes={'wght':weight}
        if 'opsz' in [a.axisTag for a in variable['fvar'].axes]:axes['opsz']=18
        font=instantiateVariableFont(variable,axes,inplace=True)
        buf=io.BytesIO();font.save(buf);data=buf.getvalue()
        hf=hb.Font(hb.Face(data)); hf.scale=(font['head'].unitsPerEm,)*2
        fonts[(family,weight)]=(font,hf,data)
parts=[]; texts=[]; bounds=[]
def add(s):parts.append(s)
def group(id):add(f'<g id="{id}" inkscape:groupmode="layer" inkscape:label="{id.replace("-"," ").title()}">')
def end():add('</g>')
def rect(x,y,w,h,fill,stroke='none',r=18,sw=2):
    add(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>')
def path(d,color=LINE,sw=2.5,dash=None):
    add(f'<path d="{d}" fill="none" stroke="{color}" stroke-width="{sw}" stroke-linecap="round" stroke-linejoin="round"'+(f' stroke-dasharray="{dash}"' if dash else '')+'/>')
def arrow(x1,y1,x2,y2,color=BLUE,both=False,dash=None):
    path(f'M{x1} {y1} L{x2} {y2}',color,3,dash)
    import math
    a=math.atan2(y2-y1,x2-x1)
    def head(x,y,a):
        dx,dy=10*math.cos(a),10*math.sin(a)
        px,py=5*math.sin(a),-5*math.cos(a)
        path(f'M{x-dx+px} {y-dy+py} L{x} {y} L{x-dx-px} {y-dy-py}',color,3)
    head(x2,y2,a)
    if both:head(x1,y1,a+math.pi)
def layout(s,family,weight,size):
    font,hf,_=fonts[(family,weight)]
    b=hb.Buffer();b.add_str(s);b.guess_segment_properties();hb.shape(hf,b)
    scale=size/font['head'].unitsPerEm
    return font,list(zip(b.glyph_infos,b.glyph_positions)),scale

def text(s,x,y,size=28,weight=400,color=INK,family='DM Sans',anchor='start',maxw=None):
    font,glyphs,scale=layout(s,family,weight,size)
    width=sum(p.x_advance for i,p in glyphs)*scale
    if maxw and width>maxw:raise ValueError(f'Text too wide: {s}: {width:.1f} > {maxw}')
    start=x-(width if anchor=='end' else width/2 if anchor=='middle' else 0)
    assert start>=0 and start+width<=W, (s,start,width)
    id=f'text-{len(texts):03}'
    texts.append((id,s,x,y,size,weight,color,family,anchor))
    bounds.append({'text':s,'x':round(start,2),'baseline':y,'width':round(width,2),'size':size})
    add(f'<text id="{id}" x="{x}" y="{y}" font-family="{family}" font-weight="{weight}" font-size="{size}" fill="{color}" text-anchor="{anchor}">{escape(s)}</text>')
def label(s,x,y,color=BLUE):text(s,x,y,20,700,color)
def asset(name,x,y,w,h,viewbox=None):
    el=ET.parse(A/name).getroot()
    vb=viewbox or el.get('viewBox')
    content=''.join(ET.tostring(e,encoding='unicode') for e in el if e.tag.rsplit('}',1)[-1]!='defs')
    content=content.replace('class="cls-1"',f'fill="{BLUE}"')
    add(f'<svg x="{x}" y="{y}" width="{w}" height="{h}" viewBox="{vb}">{content}</svg>')

group('background');rect(0,0,W,H,PAPER,r=0);rect(0,0,W,12,BLUE,r=0);end()
group('title-and-brand')
asset('zechub-blue.svg',80,64,62,62,'75 75 930 930')
text('ZecHub',160,106,34,700,BLUE)
text('ZCASH EXPLAINED',1520,102,21,700,MUTED,anchor='end')
text('How Grayscale’s ZCSH',80,218,68,700,family='Syne',maxw=1440)
text('ETP actually works',80,296,68,700,family='Syne',maxw=1440)
text('A third-party investment product holding real ZEC.',84,353,30,400,MUTED)
end()
group('conversion-history')
rect(80,395,1440,118,'#EAF2F9',r=16)
label('BEFORE',108,429)
text('Grayscale Zcash Trust',108,478,31,600,maxw=480)
arrow(618,457,700,457)
label('AFTER CONVERSION',748,429)
text('ZCSH · The Zcash ETF',748,478,31,600,maxw=440)
text('NYSE Arca debut',1490,447,22,400,MUTED,anchor='end')
text('Aug 25, 2026',1490,482,26,600,anchor='end')
end()
group('role-connectors')
# Solid, unarrowed lines denote services. Dashed line denotes listing.
path('M790 710 V776',LINE)
path('M440 854 H570',LINE)
path('M440 1043 H570',LINE)
path('M1010 907 H1160',BLUE,dash='7 7')
text('Shares',1085,877,22,500,BLUE,anchor='middle')
text('listed here',1085,946,21,400,MUTED,anchor='middle')
# Basket activity belongs to APs; brokerage trading belongs to investors.
arrow(700,1106,700,1254,BLUE,both=True)
text('Create / redeem',735,1165,24,600,BLUE,maxw=305)
text('share baskets',735,1200,24,400,MUTED)
arrow(1340,1028,1340,1254,BLUE,both=True)
text('Buy / sell',1370,1136,23,600,BLUE,maxw=150)
text('shares',1370,1170,23,400,MUTED)
end()
group('grayscale-sponsor')
rect(570,584,440,126,'#FFFFFF','#D8E3EC',r=16)
label('SPONSOR',600,621)
text('Grayscale',600,673,38,700)
end()
group('fund-and-zec-holdings')
rect(570,776,440,330,BLUE,r=22)
text('THE FUND',600,819,20,700,'#FFFFFF')
text('ZCSH',600,885,58,700,'#FFFFFF',family='Syne')
text('The Zcash ETF',600,928,29,500,'#FFFFFF')
rect(596,954,388,126,'#FFF2CF',r=13)
asset('zcash-yellow.svg',617,982,69,69,'270 270 540 540')
text('Holds real ZEC',707,1003,29,700,maxw=255)
text('The underlying asset',707,1041,23,400,MUTED,maxw=255)
end()
group('custodian')
rect(80,780,360,148,'#FFFFFF','#D8E3EC',r=16)
label('DIGITAL ASSET CUSTODIAN',106,819)
text('Coinbase Custody',106,864,30,700,maxw=308)
text('Safekeeps the fund’s ZEC',106,901,23,400,MUTED,maxw=308)
end()
group('administrator')
rect(80,975,360,136,'#FFFFFF','#D8E3EC',r=16)
label('ADMINISTRATOR',106,1014)
text('BNY',106,1058,34,700)
text('Fund accounting & records',106,1091,22,400,MUTED,maxw=308)
end()
group('exchange')
rect(1160,800,360,228,'#FFFFFF','#D8E3EC',r=16)
label('STOCK EXCHANGE',1186,841)
text('NYSE Arca',1186,898,36,700,maxw=308)
text('ZCSH shares trade',1186,948,26,400,MUTED)
text('on the exchange',1186,983,26,400,MUTED)
end()
group('authorized-participants')
rect(570,1254,440,202,'#EAF2F9','#BED4E7',r=16)
label('AUTHORIZED PARTICIPANTS',596,1295)
text('Jane Street Capital, LLC',596,1340,29,600,maxw=388)
text('Virtu Americas LLC',596,1380,29,600,maxw=388)
text('Create & redeem in large blocks',596,1426,24,400,MUTED,maxw=388)
end()
group('investors')
rect(1160,1254,360,202,'#EAF2F9','#BED4E7',r=16)
label('INVESTORS',1186,1295)
text('Brokerage account',1186,1340,29,600,maxw=308)
text('Own fund shares',1186,1387,26,500)
text('No ZEC in your wallet',1186,1426,24,400,MUTED,maxw=308)
end()
group('redemption-note')
text('AP redemption: cash only under the Aug 24, 2026 prospectus.',570,1497,23,500,MUTED,maxw=950)
end()
group('takeaway')
rect(80,1540,1440,116,INK,r=16)
text('Grayscale launched the product.',110,1589,33,700,'#FFFFFF')
text('Zcash is the network behind the asset.',110,1630,29,400,'#FFFFFF')
end()
group('sources-and-date')
text('Sources: Grayscale product page · SEC prospectus, Aug 24, 2026',80,1696,21,400,MUTED,maxw=1070)
text('As of Sep 9, 2026',1520,1696,21,500,MUTED,anchor='end')
text('ETP = exchange-traded product. “The Zcash ETF” is the product name; it is not a 1940 Act registered fund.',80,1731,19,400,MUTED,maxw=1440)
end()

fontcss=''.join('@font-face{font-family:"%s";font-weight:%s;src:url(data:font/ttf;base64,%s) format("truetype");}'%(fam,wt,base64.b64encode(v[2]).decode()) for (fam,wt),v in fonts.items())
head=f'''<svg xmlns="http://www.w3.org/2000/svg" xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape" width="{W}" height="{H}" viewBox="0 0 {W} {H}" role="img" aria-labelledby="title desc">
<title id="title">How Grayscale’s ZCSH ETP actually works</title>
<desc id="desc">Grayscale converted its Zcash Trust to ZCSH, an exchange-traded product holding ZEC. Grayscale sponsors the fund, Coinbase Custody safekeeps the ZEC, and BNY administers the fund. Jane Street Capital and Virtu Americas create and redeem share baskets. Investors buy and sell ZCSH shares on NYSE Arca through brokerage accounts. AP redemptions are cash only under the August 24, 2026 prospectus. Investors hold shares, not ZEC in a personal wallet.</desc>
'''
svg=head+'<defs><style>'+fontcss+'</style></defs>'+''.join(parts)+'</svg>'
(ROOT/'source/zcsh-etp.editable.svg').write_text(svg)
# Outline text with HarfBuzz shaping: portable vectors, no external fonts or raster images.
ns='{http://www.w3.org/2000/svg}'
ET.register_namespace('',ns[1:-1]);ET.register_namespace('inkscape','http://www.inkscape.org/namespaces/inkscape')
root=ET.fromstring(svg)
lookup={t[0]:t for t in texts}
for parent in root.iter():
    for el in list(parent):
        if el.tag != ns+'text':continue
        id,s,x,y,size,weight,color,family,anchor=lookup[el.get('id')]
        font,glyphs,scale=layout(s,family,weight,size)
        width=sum(p.x_advance for i,p in glyphs)*scale
        x-=width if anchor=='end' else width/2 if anchor=='middle' else 0
        gr=ET.Element(ns+'g',{'id':id,'aria-label':s,'fill':color})
        glyphset=font.getGlyphSet();order=font.getGlyphOrder();cursor=0
        for info,pos in glyphs:
            pen=SVGPathPen(glyphset);glyphset[order[info.codepoint]].draw(pen)
            d=pen.getCommands()
            if d:
                tx=x+(cursor+pos.x_offset)*scale;ty=y-pos.y_offset*scale
                ET.SubElement(gr,ns+'path',{'d':d,'transform':f'translate({tx:.5f} {ty:.5f}) scale({scale:.7f} {-scale:.7f})'})
            cursor+=pos.x_advance
        i=list(parent).index(el);parent.remove(el);parent.insert(i,gr)
for el in list(root):
    if el.tag==ns+'defs':root.remove(el)
outlined=ET.tostring(root,encoding='unicode')
(O/'zcsh-etp.svg').write_text(outlined)
cairosvg.svg2png(bytestring=outlined.encode(),write_to=str(O/'zcsh-etp.png'),output_width=W*2,output_height=H*2)
cairosvg.svg2png(bytestring=outlined.encode(),write_to=str(O/'zcsh-etp-preview.png'),output_width=800,output_height=880)
(O/'text-layout.json').write_text(json.dumps(bounds,indent=2))
print(f'Built {len(texts)} text elements; editable SVG, outlined SVG, 3200×3520 PNG, 800×880 preview.')
